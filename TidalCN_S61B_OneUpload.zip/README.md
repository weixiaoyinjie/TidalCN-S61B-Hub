# 音乐中文助手 · S61B（MVP 0.1.0）

这是一个**非 TIDAL / Samsung 官方**的 Android 原生 Java 演示应用。目标：帮助中文用户使用自己的合法 TIDAL 账号搜歌，使用**官方 TIDAL App**通过 **TIDAL Connect** 直连 Samsung HW-S61B + W510，并在单独页面尝试读取 SmartThings 已公开的音响控制能力。

## 当前完成的功能

- 中文界面：中文艺名内置对照表；Wikidata 官方公开 API 查询中文艺名对应的英文候选（供用户核实）；点击候选后可继续搜 TIDAL。
- TIDAL 官方公开 API：Authorization Code + PKCE（需要用户自建 Developer App Client ID）以及短期 token 测试输入。支持新 `/v2/searchResults?filter[query]=…` 搜索方式，尝试解出 `included` 和 `relationships` 返回结果。
- 曲目 / 专辑 / 艺人搜索结果：点击后打开官方 TIDAL 对应内容链接。由于版权和 Connect 设备控制权限限制，本应用**不直接播放 TIDAL 流媒体，也不直接给 S61B 下发 TIDAL Connect 播放/队列指令**。
- Atmos 发现：提供 TIDAL 官方精选/新上架 Atmos 歌单直达链接；同时可用关键词查找候选，不假装使用未公开的 Atmos 元数据字段。只有官方 TIDAL 页面标识能确认具体版本。
- 本机收藏：只保存用户点击的曲目/专辑链接。不是同步 TIDAL 账号收藏。
- SmartThings：个人短期 PAT 检索设备、选择 S61B，读取组件能力。设备若报告 `audioVolume` / `audioMute`，允许对应的加减音量、静音、恢复音量和查询状态。设备未公开时**不会显示虚假可用的控制按钮**。
- 敏感令牌使用 Android Keystore AES-GCM 保存，`allowBackup=false`，不在代码或 GitHub 中附带密钥。手机卸载后需重新授权。

## 重要限制

1. **TIDAL Connect 的第三方控制器协议不公开**：设备合作伙伴才可集成 TIDAL Connect。手机可用官方 TIDAL App 选音响，本应用只能在发现曲目后引导打开官方 App。
2. **没有公开保证完整准确的 Dolby Atmos 搜索过滤字段**：关键字搜索是线索，不是格式鉴定。
3. **S61B 不一定通过 SmartThings API 公开音效、低音炮/W510 或独立电源控制**：本版只实现有标准能力描述的音量和静音。其他音效可通过官方 SmartThings App。
4. **SmartThings PAT 通常仅有效 24 小时**。这是个人测试版。长期使用应按 SmartThings 文档做 OAuth 2.0 服务集成，通常需要安全的 OAuth 后端；不要把 client secret 写进 APK。
5. OAuth TIDAL 开发者应用可用的权限因开发者审核与注册配置而异；如授权失败，可以使用开发者平台合法获得的短期 Access Token 测试。不要使用非公开 TIDAL API、抓包绕过权限或 DRM。
6. 本项目尚**未在真实 Samsung S61B / TIDAL 会员账户上验证**；API 可能调整，需要根据 HTTP 响应做适配。

## 授权 TIDAL

1. 在 https://developer.tidal.com/ 创建开发者应用，取得 **Client ID**。不要把 Client Secret 放进手机 APK、聊天或 GitHub。
2. 若后台支持注册自定义 URI，设置回调 `tidalcn://oauth`；如后台不允许，不能使用这个演示版的 PKCE 回调，需改为支持的安全回调方案。
3. 打开 App → 设置 → 输入 Client ID → 保存 / 授权登录；登录完成回到 App，之后搜索 TIDAL 目录。
4. 如果开发者授权不开放，可以使用合法取得的短期测试 Access Token 先验证目录搜索。

## SmartThings 测试

1. 先用官方 SmartThings App 添加 S61B。
2. https://account.smartthings.com/tokens 生成**短期** PAT，按需开通设备只读、控制权限。
3. 在本 App 粘贴 PAT 并点击检测设备，选择你那台 S61B。
4. App 读取设备的 `components.main.capabilities` 决定哪些遥控功能确实存在。不会声称 W510 低音控制可用。

## 如何安装 APK（GitHub Actions）

推荐仓库名 `TidalCN-S61B-Hub`。在 GitHub 新建空仓库，上传本压缩包 `TidalCN_S61B_OneUpload.zip`，在 `.github/workflows/build-apk.yml` 添加根目录 ZIP 内同名工作流文件。进入 Actions → **Build Music Chinese S61B APK** → Run workflow，成功后在 Artifacts 下载 `MusicChineseS61B-debug-apk`。

工作流会在 GitHub runner 解压 ZIP，调用 Java 17、Gradle 8.10.2、Android Gradle Plugin 8.6.1、Android SDK 35 构建。也可以将 ZIP 解压后，将整个项目代码上传仓库，再启动工作流。

> 这是未经云端/设备实机编译验证的可开发 MVP 源码，不是现成 APK。需要通过 GitHub Actions 验证编译结果。

## 官方文档
- https://developer.tidal.com/documentation/connect
- https://developer.tidal.com/documentation/api-sdk/api-sdk-authorization
- https://developer.tidal.com/reference
- https://developer.smartthings.com/docs/getting-started/quickstart
- https://developer.smartthings.com/docs/service-integrations/control-devices

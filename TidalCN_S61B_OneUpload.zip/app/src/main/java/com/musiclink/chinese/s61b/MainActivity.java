package com.musiclink.chinese.s61b;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Unofficial Chinese TIDAL music finder and SmartThings remote.
 * Official TIDAL app remains the only TIDAL Connect controller.
 */
public class MainActivity extends Activity {
    private static final int BG = 0xff0c121a, PANEL = 0xff182431, ACCENT = 0xff33d8b5,
            TXT = 0xffeef4f8, DIM = 0xffadc0cf;
    private static final String REDIRECT = "tidalcn://oauth";
    private static final String TIDAL_API = "https://openapi.tidal.com/v2";
    private static final String SMART_API = "https://api.smartthings.com/v1";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private SecurePrefs secure;
    private EditText queryEdit, clientIdEdit, tokenEdit, patEdit, countryEdit;
    private TextView status, connectedLabel, soundStatus;
    private LinearLayout results, favorites, devices, soundControls, aliasResults;
    private String activeDeviceId = "", activeDeviceName = "";
    private boolean volAvailable, muteAvailable;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        secure = new SecurePrefs(this);
        render();
        onOAuthRedirect(getIntent());
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i); onOAuthRedirect(i);
    }
    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }

    private int dp(int v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView txt(String s, int sz, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0,dp(4),0,dp(4)); return t;
    }
    private LinearLayout panel(LinearLayout parent) {
        LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(bg(PANEL, 16)); p.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,0,0,dp(15)); parent.addView(p,lp); return p;
    }
    private Button button(String label, LinearLayout p, Runnable fn) {
        Button b = new Button(this); b.setText(label); b.setTextSize(14);
        b.setAllCaps(false); b.setTextColor(BG); b.setBackground(bg(ACCENT, 10));
        b.setOnClickListener(v -> fn.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(48));
        lp.setMargins(0,dp(6),0,dp(4)); p.addView(b,lp); return b;
    }
    private void smallButton(String title, LinearLayout row, Runnable run) {
        Button b = new Button(this); b.setText(title); b.setAllCaps(false);
        b.setTextSize(12); b.setTextColor(TXT); b.setBackground(bg(0xff2b4352,9));
        b.setOnClickListener(v -> run.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,dp(42),1);
        lp.setMargins(dp(2),dp(2),dp(2),dp(2)); row.addView(b,lp);
    }
    private EditText edit(LinearLayout root, String hint, String value, boolean password) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(TXT);
        e.setHintTextColor(0xff7e97a6); e.setTextSize(15); e.setHint(hint);
        e.setPadding(dp(13),dp(9),dp(13),dp(9)); e.setBackground(bg(0xff0f1b25,8));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setText(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(48));
        lp.setMargins(0,dp(5),0,dp(8)); root.addView(e,lp); return e;
    }
    private LinearLayout row(LinearLayout p) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        p.addView(r,new LinearLayout.LayoutParams(-1,-2)); return r;
    }
    private void heading(LinearLayout p, String s) { p.addView(txt(s,19,TXT,true)); }
    private void tip(LinearLayout p, String s) { p.addView(txt(s,12,DIM,false)); }
    private void render() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(24),dp(18),dp(36)); scroll.addView(root); setContentView(scroll);
        root.addView(txt("音乐中文助手 · S61B",25,ACCENT,true));
        root.addView(txt("中文发现音乐 / 官方 TIDAL Connect / SmartThings 音响控制",13,DIM,false));
        status = txt("准备就绪。TIDAL Connect 播放仍由官方 TIDAL 应用执行。",12,ACCENT,false);
        root.addView(status);

        LinearLayout find = panel(root);
        heading(find,"01  中文找歌与 Atmos 线索");
        tip(find,"可输入中文歌手名，转换英文名后搜索官方 TIDAL 目录。Atmos 结果仅作候选线索，不表示每首都经过格式验证。");
        queryEdit = edit(find,"歌手/专辑，例如：王菲、周杰伦、Coldplay", "",false);
        LinearLayout r1 = row(find);
        smallButton("中文名转换",r1,this::translateName);
        smallButton("搜索 TIDAL",r1,()->search(false));
        LinearLayout r2 = row(find);
        smallButton("查找 Atmos 线索",r2,()->search(true));
        smallButton("打开官方 TIDAL",r2,()->openApp("com.aspiro.tidal","https://tidal.com"));
        tip(find,"TIDAL 官方 Atmos 精选歌单（比仅按关键词检索更可靠）：");
        LinearLayout rAtmos = row(find);
        smallButton("Atmos 精选",rAtmos,()->openUrl("https://tidal.com/playlist/cc065c40-951f-4bf7-aaa8-e6724f53ff7f"));
        smallButton("Atmos 新上架",rAtmos,()->openUrl("https://tidal.com/playlist/842c6d95-a332-48dc-af28-92c573bd4fdc"));
        aliasResults = new LinearLayout(this); aliasResults.setOrientation(LinearLayout.VERTICAL); find.addView(aliasResults);
        results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); find.addView(results);

        LinearLayout fav = panel(root); heading(fav,"02  我的中文收藏");
        tip(fav,"收藏仅保存在本机，不会改动 TIDAL 账号中的收藏。");
        favorites = new LinearLayout(this); favorites.setOrientation(LinearLayout.VERTICAL); fav.addView(favorites);
        showFavorites();

        LinearLayout sound = panel(root); heading(sound,"03  S61B 音量控制");
        tip(sound,"通过 SmartThings 读取设备真实能力。若设备未开放音量/静音能力，不会提供无效遥控键。不会改变 TIDAL Connect 播放路径。");
        connectedLabel = txt("尚未选择设备",14,DIM,false); sound.addView(connectedLabel);
        soundStatus = txt("",12,DIM,false); sound.addView(soundStatus);
        devices = new LinearLayout(this); devices.setOrientation(LinearLayout.VERTICAL); sound.addView(devices);
        soundControls = new LinearLayout(this); soundControls.setOrientation(LinearLayout.VERTICAL); sound.addView(soundControls);
        LinearLayout r3 = row(sound);
        smallButton("检测设备",r3,this::scanDevices);
        smallButton("Samsung SmartThings",r3,()->openApp("com.samsung.android.oneconnect","https://www.smartthings.com"));

        LinearLayout setting = panel(root); heading(setting,"04  接入设置");
        tip(setting,"TIDAL 开发者 Client ID（不填写 Client Secret）。回调地址在开发者平台填写 tidalcn://oauth，OAuth PKCE 登录后搜索。也可以临时填写合法的用户 Access Token 调试。");
        clientIdEdit = edit(setting,"TIDAL Client ID",prefs.getString("client_id",""),false);
        countryEdit = edit(setting,"国家代码（默认 AR）",prefs.getString("country","AR"),false);
        tokenEdit = edit(setting,"可选：临时 TIDAL Access Token", "",true);
        LinearLayout r4 = row(setting);
        smallButton("保存 / 授权登录",r4,()->{ saveInputs(); startOAuth(); });
        smallButton("使用临时 Token",r4,()->{
            String t=tokenEdit.getText().toString().trim();
            if (t.isEmpty()) { info("请输入合法的短期 Token"); return; }
            secure.put("tidal_access",t); secure.put("tidal_refresh",""); tokenEdit.setText("");
            saveInputs(); info("已保存测试 Token（Android Keystore 加密）");
        });
        tip(setting,"SmartThings 测试：在 Samsung 账户创建仅有设备读取/控制权限的 PAT。新 PAT 通常仅有效 24 小时；正式版应改成 OAuth 服务集成。");
        patEdit = edit(setting,"SmartThings 测试 PAT", "",true);
        LinearLayout r5 = row(setting);
        smallButton("保存 SmartThings PAT",r5,()->{
            String t=patEdit.getText().toString().trim();
            if (t.isEmpty()) { info("请填写 PAT"); return; }
            secure.put("st_pat",t); patEdit.setText(""); info("测试 PAT 已安全保存，可点击检测设备");
        });
        smallButton("获取 PAT 的网页",r5,()->openUrl("https://account.smartthings.com/tokens"));
        tip(setting,"非 TIDAL / Samsung 官方应用。不会绕过会员、DRM 或 TIDAL Connect 限制。W510 低音调节需要 S61B 实际开放对应能力后再实现。");
        if (!prefs.getString("device_id","").isEmpty()) {
            activeDeviceId=prefs.getString("device_id","");
            activeDeviceName=prefs.getString("device_name","");
            connectedLabel.setText("已记住设备："+activeDeviceName);
        }
    }
    private void info(String m) { runOnUiThread(()->status.setText(m)); }
    private void async(Runnable r) { worker.execute(()->{
        try {r.run();} catch(Exception e) {info("操作失败："+e.getMessage());}
    }); }
    private void saveInputs() {
        prefs.edit().putString("client_id",clientIdEdit.getText().toString().trim())
                .putString("country",countryEdit.getText().toString().trim().toUpperCase(Locale.ROOT)).apply();
    }
    private String country() {String s = prefs.getString("country","AR"); return s.matches("[A-Z]{2}")?s:"AR";}
    private void openUrl(String url) {
        try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
        catch (Exception e) {info("无法打开链接："+url);}
    }
    private void openApp(String pkg, String fallback) {
        try {
            Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
            if(i!=null){startActivity(i);return;}
        } catch(Exception ignored) {}
        openUrl(fallback);
    }
    private static String enc(String s) {try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private static String rand() {
        byte[] r = new byte[32];new SecureRandom().nextBytes(r);
        return Base64.encodeToString(r,Base64.NO_WRAP|Base64.URL_SAFE|Base64.NO_PADDING);
    }
    private static String challenge(String verifier) throws Exception {
        byte[] b=MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
        return Base64.encodeToString(b,Base64.NO_WRAP|Base64.URL_SAFE|Base64.NO_PADDING);
    }
    private void startOAuth() {
        String id=prefs.getString("client_id","");
        if(id.isEmpty()) {info("先在 developer.tidal.com 建立 App 并填写 Client ID");return;}
        try {
            String verifier=rand(), state=rand();
            prefs.edit().putString("pkce",verifier).putString("oauth_state",state).apply();
            String url="https://login.tidal.com/authorize?response_type=code&client_id="+enc(id)
                    +"&redirect_uri="+enc(REDIRECT)+"&scope="+enc("user.read")
                    +"&code_challenge_method=S256&code_challenge="+enc(challenge(verifier))
                    +"&state="+enc(state);
            openUrl(url);
        } catch (Exception e) {info("无法启动授权："+e.getMessage());}
    }
    private void onOAuthRedirect(Intent intent) {
        if (intent==null || intent.getData()==null) return;
        Uri uri=intent.getData();
        if (!"tidalcn".equals(uri.getScheme()) || !"oauth".equals(uri.getHost()))return;
        String state=uri.getQueryParameter("state");
        String savedState=prefs.getString("oauth_state","");
        String code=uri.getQueryParameter("code");
        if (state==null || savedState.isEmpty() || !savedState.equals(state)) {info("OAuth state 不匹配，已拒绝回调");return;}
        String verifier=prefs.getString("pkce","");
        prefs.edit().remove("oauth_state").remove("pkce").apply();
        if (code==null) {info("授权未完成："+uri.getQueryParameter("error"));return;}
        info("授权完成，正在获取访问令牌……");
        async(()->{
            try {
                String form="grant_type=authorization_code&client_id="+enc(prefs.getString("client_id",""))
                        +"&code="+enc(code)+"&redirect_uri="+enc(REDIRECT)+"&code_verifier="+enc(verifier);
                JSONObject j=request("POST","https://auth.tidal.com/v1/oauth2/token",null,form,"application/x-www-form-urlencoded");
                saveTidalTokens(j); info("TIDAL 授权成功，可以搜索中文音乐");
            }catch(Exception e){info("授权交换失败："+e.getMessage()+"。请检查开发者平台回调地址和权限");}
        });
    }
    private void saveTidalTokens(JSONObject j) {
        secure.put("tidal_access",j.optString("access_token",""));
        if(j.has("refresh_token"))secure.put("tidal_refresh",j.optString("refresh_token",""));
        prefs.edit().putLong("token_expires",System.currentTimeMillis()+Math.max(60,j.optLong("expires_in",3600)-90)*1000).apply();
    }
    private String accessToken() throws Exception {
        String refresh=secure.get("tidal_refresh");
        String token=secure.get("tidal_access");
        if(!refresh.isEmpty() && System.currentTimeMillis()>prefs.getLong("token_expires",0)) {
            String form="grant_type=refresh_token&refresh_token="+enc(refresh)
                    +"&client_id="+enc(prefs.getString("client_id",""));
            JSONObject j=request("POST","https://auth.tidal.com/v1/oauth2/token",null,form,"application/x-www-form-urlencoded");
            saveTidalTokens(j);return secure.get("tidal_access");
        }
        if(token.isEmpty())throw new Exception("还未连接 TIDAL 开发者 API；先授权登录，或填入临时访问令牌");
        return token;
    }
    private JSONObject request(String method,String url,String token,String body,String contentType) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod(method);c.setConnectTimeout(12000);c.setReadTimeout(15000);
        c.setRequestProperty("Accept","application/vnd.api+json, application/json");
        c.setRequestProperty("User-Agent","MusicChineseS61B/0.1 contact: local-personal-tool");
        if(token!=null && !token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
        if(body!=null){
            c.setDoOutput(true);c.setRequestProperty("Content-Type",contentType);
            try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}
        }
        int status=c.getResponseCode();
        try(InputStream stream=status<400?c.getInputStream():c.getErrorStream()) {
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            if(stream!=null){byte[] buf=new byte[8192];int n;while((n=stream.read(buf))!=-1)out.write(buf,0,n);}
            String result=out.toString("UTF-8");
            if(status>=400)throw new Exception("HTTP "+status+"："+result.substring(0,Math.min(190,result.length())));
            return result.isEmpty()?new JSONObject():new JSONObject(result);
        }finally{c.disconnect();}
    }
    private static final Map<String,String> ALIASES = new LinkedHashMap<>();
    static {
        ALIASES.put("周杰伦","Jay Chou");ALIASES.put("王菲","Faye Wong");
        ALIASES.put("邓丽君","Teresa Teng");ALIASES.put("张学友","Jacky Cheung");
        ALIASES.put("陈奕迅","Eason Chan");ALIASES.put("林俊杰","JJ Lin");
        ALIASES.put("蔡依林","Jolin Tsai");ALIASES.put("张国荣","Leslie Cheung");
        ALIASES.put("刘德华","Andy Lau");ALIASES.put("五月天","Mayday");
        ALIASES.put("林忆莲","Sandy Lam");ALIASES.put("莫文蔚","Karen Mok");
    }
    private void translateName() {
        String input=queryEdit.getText().toString().trim();
        aliasResults.removeAllViews();
        if(input.isEmpty()){info("请先输入中文歌手名");return;}
        String local=ALIASES.get(input);
        if(local!=null){showAlias(input,local,"内置常见歌手名称表");return;}
        info("正在 Wikidata 查找英文艺名候选……");
        async(()->{
            try{
                String url="https://www.wikidata.org/w/api.php?action=wbsearchentities&format=json&language=zh&limit=5&search="+enc(input);
                JSONObject j=request("GET",url,null,null,null);JSONArray a=j.optJSONArray("search");
                if(a==null || a.length()==0){info("未匹配到公开英文名称，请直接输入英文名搜索");return;}
                StringBuilder ids=new StringBuilder();
                for(int i=0;i<a.length();i++){if(i>0)ids.append('|');ids.append(a.getJSONObject(i).optString("id"));}
                JSONObject details=request("GET","https://www.wikidata.org/w/api.php?action=wbgetentities&format=json&props=labels%7Cdescriptions&languages=en&ids="+enc(ids.toString()),null,null,null);
                JSONObject entities=details.optJSONObject("entities");
                ArrayList<String[]> found=new ArrayList<>();
                for(int i=0;i<a.length();i++){
                    JSONObject v=a.getJSONObject(i), entity=entities==null?null:entities.optJSONObject(v.optString("id"));
                    JSONObject labels=entity==null?null:entity.optJSONObject("labels");
                    JSONObject en=labels==null?null:labels.optJSONObject("en");
                    String label=en==null?"":en.optString("value");
                    if(label.isEmpty())continue;
                    JSONObject descriptions=entity.optJSONObject("descriptions");
                    JSONObject desc=descriptions==null?null:descriptions.optJSONObject("en");
                    found.add(new String[]{label,desc==null?"公开实体候选":desc.optString("value")});
                }
                runOnUiThread(()->{
                    aliasResults.removeAllViews();
                    for(String[] match:found)showAlias(input,match[0],match[1]);
                    info(found.isEmpty()?"找不到英文名称，可手动输入":"点击正确的艺名候选，再搜索 TIDAL");
                });
            }catch(Exception e){info("中文名称匹配失败："+e.getMessage());}
        });
    }
    private void showAlias(String chinese,String en,String source){
        TextView x=txt("候选："+en+" · "+source+"（点击使用）",14,ACCENT,false);
        aliasResults.addView(x);x.setOnClickListener(v->{queryEdit.setText(en);queryEdit.setSelection(en.length());search(false);});
    }
    private static class MusicItem {
        final String type,id,title,detail;
        MusicItem(String type,String id,String title,String detail){this.type=type;this.id=id;this.title=title;this.detail=detail;}
        String url(){return "https://tidal.com/browse/"+type+"/"+enc(id);}
    }
    private MusicItem parseMusic(JSONObject d){
        String type=d.optString("type","").toLowerCase(Locale.ROOT);
        if(type.endsWith("s"))type=type.substring(0,type.length()-1);
        if(!type.equals("track")&&!type.equals("album")&&!type.equals("artist")&&!type.equals("playlist"))return null;
        JSONObject a=d.optJSONObject("attributes");if(a==null)a=new JSONObject();
        String title=a.optString("title",a.optString("name",""));
        if(title.isEmpty())return null;
        String detail=a.optString("releaseDate","");
        return new MusicItem(type,d.optString("id",""),title,detail);
    }
    private void search(boolean atmos) {
        String q=queryEdit.getText().toString().trim();
        if(atmos)q=q.isEmpty()?"Dolby Atmos":q+" Dolby Atmos";
        if(q.isEmpty()){info("请填写歌手或者专辑名称");return;}
        saveInputs();String keyword=q;
        info("正在搜索官方 TIDAL 目录："+keyword);
        async(()->{
            try {
                String token=accessToken();
                String url=TIDAL_API+"/searchResults?filter%5Bquery%5D="+enc(keyword)
                        +"&countryCode="+enc(country())+"&include=albums,artists,tracks,playlists";
                JSONObject j=request("GET",url,token,null,null);
                LinkedHashMap<String,MusicItem> found=new LinkedHashMap<>();
                JSONArray included=j.optJSONArray("included");
                if(included!=null)for(int i=0;i<included.length();i++){
                    MusicItem m=parseMusic(included.optJSONObject(i)==null?new JSONObject():included.optJSONObject(i));
                    if(m!=null)found.put(m.type+":"+m.id,m);
                }
                // Some API responses contain relationship identifiers but no included resources.
                // Resolve a few of those against the public, documented TIDAL v2 catalog.
                if(found.size()<3){
                    JSONArray data=j.optJSONArray("data");
                    if(data!=null)for(int i=0;i<data.length() && i<2;i++){
                        JSONObject obj=data.optJSONObject(i);if(obj==null)continue;
                        JSONObject rel=obj.optJSONObject("relationships");if(rel==null)continue;
                        for(String kind:new String[]{"albums","tracks","artists","playlists"}){
                            JSONObject relation=rel.optJSONObject(kind);if(relation==null)continue;
                            JSONArray refs=relation.optJSONArray("data");if(refs==null)continue;
                            for(int k=0;k<refs.length() && k<4;k++){
                                JSONObject ref=refs.optJSONObject(k);if(ref==null)continue;
                                String id=ref.optString("id","");if(id.isEmpty())continue;
                                try{
                                    JSONObject fetched=request("GET",TIDAL_API+"/"+kind+"/"+enc(id)+"?countryCode="+enc(country()),token,null,null);
                                    JSONObject entity=fetched.optJSONObject("data");
                                    if(entity!=null){MusicItem m=parseMusic(entity);if(m!=null)found.put(m.type+":"+m.id,m);}
                                }catch(Exception ignored) { /* Search results may be region restricted. */ }
                            }
                        }
                    }
                }
                ArrayList<MusicItem> items=new ArrayList<>(found.values());
                runOnUiThread(()->showResults(items,atmos,keyword));
            }catch(Exception e){info("TIDAL 搜索失败："+e.getMessage());}
        });
    }
    private void showResults(ArrayList<MusicItem> items,boolean atmos,String keyword) {
        results.removeAllViews();
        if(atmos)tip(results,"注意：这些是“Dolby Atmos”关键词检索线索，不是已验证的 Atmos 音轨。打开 TIDAL 后以官方 Atmos 标识为准。");
        if(items.isEmpty()){
            tip(results,"API 没有返回可识别的曲目；请确认开发者权限和地区，或在官方 TIDAL 中继续搜索："+keyword);
            button("打开官方 TIDAL",results,()->openApp("com.aspiro.tidal","https://tidal.com"));
            info("当前未获取到目录结果");return;
        }
        for(int i=0;i<Math.min(20,items.size());i++){
            MusicItem m=items.get(i);
            LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(8),dp(9),dp(8),dp(9));
            p.setBackground(bg(0xff223340,10));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,0);results.addView(p,lp);
            p.addView(txt(m.title,16,TXT,true));p.addView(txt(m.type.toUpperCase(Locale.ROOT)+" · "+m.detail,12,DIM,false));
            LinearLayout r=row(p);
            smallButton("在 TIDAL 打开",r,()->openUrl(m.url()));
            smallButton("收藏",r,()->saveFavorite(m));
        }
        info("返回 "+items.size()+" 条目录结果。播放请在官方 TIDAL 中连接 S61B。");
    }
    private void saveFavorite(MusicItem m) {
        try {
            JSONArray a=new JSONArray(prefs.getString("favorites","[]"));
            for(int i=0;i<a.length();i++)if(m.url().equals(a.getJSONObject(i).optString("url"))) {info("已经收藏");return;}
            JSONObject j=new JSONObject();j.put("title",m.title);j.put("url",m.url());j.put("kind",m.type);
            a.put(j);prefs.edit().putString("favorites",a.toString()).apply();showFavorites();info("已加入本地收藏");
        }catch(Exception e){info("收藏失败："+e.getMessage());}
    }
    private void showFavorites() {
        favorites.removeAllViews();
        JSONArray a;try{a=new JSONArray(prefs.getString("favorites","[]"));}catch(Exception e){a=new JSONArray();}
        if(a.length()==0){tip(favorites,"还没有收藏曲目或专辑");return;}
        for(int i=0;i<a.length();i++){
            JSONObject item=a.optJSONObject(i);if(item==null)continue;
            String label=item.optString("title","曲目"),url=item.optString("url","");
            int index=i;LinearLayout r=row(favorites);
            smallButton(label,r,()->openUrl(url));
            smallButton("移除",r,()->removeFavorite(index));
        }
    }
    private void removeFavorite(int index) {
        try{
            JSONArray orig=new JSONArray(prefs.getString("favorites","[]")),out=new JSONArray();
            for(int i=0;i<orig.length();i++)if(i!=index)out.put(orig.get(i));
            prefs.edit().putString("favorites",out.toString()).apply();showFavorites();
        }catch(Exception e){info("操作失败："+e.getMessage());}
    }
    private String smartToken() throws Exception {
        String pat=secure.get("st_pat");
        if(pat.isEmpty())throw new Exception("请先设置 SmartThings 测试 PAT");
        return pat;
    }
    private void scanDevices() {
        info("正在读取 SmartThings 设备列表……");
        async(()->{
            try {
                JSONObject j=request("GET",SMART_API+"/devices",smartToken(),null,null);
                JSONArray a=j.optJSONArray("items");
                if(a==null||a.length()==0){info("SmartThings 没有返回设备，请确认 S61B 已添加到 SmartThings");return;}
                ArrayList<String[]> all=new ArrayList<>();
                for(int i=0;i<a.length();i++){
                    JSONObject d=a.optJSONObject(i);if(d==null)continue;
                    String name=d.optString("label",d.optString("name","设备"));
                    all.add(new String[]{d.optString("deviceId"),name});
                }
                runOnUiThread(()->{
                    devices.removeAllViews();
                    tip(devices,"选择 S61B（不是 W510 或电视）：");
                    for(String[] d:all){
                        if(d[0].isEmpty())continue;
                        smallDeviceButton(devices,d[1],()->selectDevice(d[0],d[1]));
                    }
                    info("已获取 "+all.size()+" 台设备；请选择 S61B");
                });
            }catch(Exception e){info("SmartThings 获取设备失败："+e.getMessage());}
        });
    }
    private void smallDeviceButton(LinearLayout p,String name,Runnable run) {
        Button b=button("选择设备："+name,p,run);b.setBackground(bg(0xff29516a,9));b.setTextColor(TXT);
    }
    private void selectDevice(String id,String name) {
        activeDeviceId=id;activeDeviceName=name;
        prefs.edit().putString("device_id",id).putString("device_name",name).apply();
        connectedLabel.setText("已选择："+name);
        info("正在检查 " + name + " 的公开控制能力……");
        async(()->{
            try {
                JSONObject j=request("GET",SMART_API+"/devices/"+enc(id),smartToken(),null,null);
                JSONArray comps=j.optJSONArray("components");
                boolean vol=false,mute=false;
                if(comps!=null)for(int i=0;i<comps.length();i++){
                    JSONObject comp=comps.optJSONObject(i);if(comp==null)continue;
                    if(!"main".equals(comp.optString("id")))continue;
                    JSONArray caps=comp.optJSONArray("capabilities");if(caps==null)continue;
                    for(int k=0;k<caps.length();k++){
                        JSONObject cap=caps.optJSONObject(k);if(cap==null)continue;
                        String nameCap=cap.optString("id");
                        if(nameCap.equals("audioVolume"))vol=true;
                        if(nameCap.equals("audioMute"))mute=true;
                    }
                }
                boolean canVol=vol,canMute=mute;
                runOnUiThread(()->{volAvailable=canVol;muteAvailable=canMute;renderSoundControls();});
                checkSoundStatus();
            }catch(Exception e){info("设备能力读取失败："+e.getMessage());}
        });
    }
    private void renderSoundControls() {
        soundControls.removeAllViews();
        if(!volAvailable&&!muteAvailable){
            tip(soundControls,"SmartThings 没有向此 App 开放标准音量/静音能力。请用 Samsung SmartThings 控制音效，或使用 S61B 自带遥控器。");
            return;
        }
        if(volAvailable){LinearLayout r=row(soundControls);
            smallButton("音量 −",r,()->sendSmart("audioVolume","volumeDown",new JSONArray()));
            smallButton("音量 +",r,()->sendSmart("audioVolume","volumeUp",new JSONArray()));
        }
        if(muteAvailable){LinearLayout r=row(soundControls);
            smallButton("静音",r,()->sendSmart("audioMute","mute",new JSONArray()));
            smallButton("恢复声音",r,()->sendSmart("audioMute","unmute",new JSONArray()));
        }
        button("刷新 S61B 状态",soundControls,this::checkSoundStatus);
    }
    private void checkSoundStatus() {
        if(activeDeviceId.isEmpty())return;
        async(()->{
            try{
                JSONObject j=request("GET",SMART_API+"/devices/"+enc(activeDeviceId)+"/status",smartToken(),null,null);
                JSONObject comps=j.optJSONObject("components");
                JSONObject main=comps==null?null:comps.optJSONObject("main");
                int volume=-1;String muted="未知";
                if(main!=null){
                    JSONObject av=main.optJSONObject("audioVolume");
                    if(av!=null){JSONObject v=av.optJSONObject("volume");if(v!=null)volume=v.optInt("value",-1);}
                    JSONObject am=main.optJSONObject("audioMute");
                    if(am!=null){JSONObject m=am.optJSONObject("mute");if(m!=null)muted=m.optString("value","未知");}
                }
                int level=volume;String mute=muted;
                runOnUiThread(()->soundStatus.setText("音量："+(level>=0?level:"未公开")+"   静音："+mute));
            }catch(Exception e){info("音响状态读取失败："+e.getMessage());}
        });
    }
    private void sendSmart(String capability,String command,JSONArray args) {
        if(activeDeviceId.isEmpty()){info("请先选择 S61B 设备");return;}
        if(capability.equals("audioVolume")&&!volAvailable){info("未检测到音量控制能力");return;}
        if(capability.equals("audioMute")&&!muteAvailable){info("未检测到静音控制能力");return;}
        info("发送控制指令："+command);
        async(()->{
            try{
                JSONObject cmd=new JSONObject();cmd.put("component","main");cmd.put("capability",capability);
                cmd.put("command",command);cmd.put("arguments",args);
                JSONObject body=new JSONObject();body.put("commands",new JSONArray().put(cmd));
                request("POST",SMART_API+"/devices/"+enc(activeDeviceId)+"/commands",smartToken(),body.toString(),"application/json");
                info("SmartThings 已接受命令；实际生效以音响状态为准");
                checkSoundStatus();
            }catch(Exception e){info("音响控制失败："+e.getMessage());}
        });
    }
}

package com.musiclink.chinese.s61b;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Private token storage. Keys remain inside Android Keystore. */
final class SecurePrefs {
    private static final String ALIAS = "music_chinese_s61b_aes";
    private final SharedPreferences prefs;
    SecurePrefs(Context context) { prefs = context.getSharedPreferences("protected_credentials", Context.MODE_PRIVATE); }
    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true).build());
            g.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) store.getEntry(ALIAS, null)).getSecretKey();
    }
    String get(String name) {
        String val = prefs.getString(name, "");
        if (val.isEmpty()) return "";
        try {
            byte[] raw = Base64.decode(val, Base64.NO_WRAP);
            if (raw.length < 13) return "";
            byte[] iv = new byte[12];
            System.arraycopy(raw, 0, iv, 0, iv.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            byte[] data = new byte[raw.length - iv.length];
            System.arraycopy(raw, iv.length, data, 0, data.length);
            return new String(cipher.doFinal(data), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
    void put(String name, String val) {
        if (val == null || val.isEmpty()) { prefs.edit().remove(name).apply(); return; }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(val.getBytes(StandardCharsets.UTF_8));
            byte[] all = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, all, 0, iv.length);
            System.arraycopy(encrypted, 0, all, iv.length, encrypted.length);
            prefs.edit().putString(name, Base64.encodeToString(all, Base64.NO_WRAP)).apply();
        } catch (Exception e) { throw new IllegalStateException("Could not securely store credential", e); }
    }
}
